<?php

/**
 * Fired during plugin activation
 *
 * @link       https://unelmapay.com/
 * @since      1.0.0
 *
 * @package    Unelmapay_payment_gateway
 * @subpackage Unelmapay_payment_gateway/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Unelmapay_payment_gateway
 * @subpackage Unelmapay_payment_gateway/includes
 * @author     unelmapay.com <support@unelmapay.com>
 */
class Unelmapay_payment_gateway_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
