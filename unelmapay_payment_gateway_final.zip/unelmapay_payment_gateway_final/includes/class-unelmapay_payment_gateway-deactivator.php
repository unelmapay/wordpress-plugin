<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://unelmapay.com/
 * @since      1.0.0
 *
 * @package    Unelmapay_payment_gateway
 * @subpackage Unelmapay_payment_gateway/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Unelmapay_payment_gateway
 * @subpackage Unelmapay_payment_gateway/includes
 * @author     unelmapay.com <support@unelmapay.com>
 */
class Unelmapay_payment_gateway_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
